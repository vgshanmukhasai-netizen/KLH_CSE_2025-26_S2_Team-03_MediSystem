# DSA---3-MediSearch-Project

## Run

From the project root:

```text
javac -d . src\*.java src\algorithms\*.java
java Main
```

The search reads all patient records from `src/corpus_txt`. Available algorithms:

- KMP
- Z Algorithm
- Trie
- Edit Distance
- Aho-Corasick
- Smith-Waterman
- Optimal BST disease lookup
- Rabin-Karp and suffix-array patient-record searches
- Needleman-Wunsch global sequence alignment
- Exact Held-Karp TSP ambulance route (up to 18 locations)
- Bipartite maximum matching
- Edmonds-Karp maximum flow and minimum-cut source side
- 2-approximation for undirected vertex cover
- 0/1 Knapsack
- Miller-Rabin probable-prime test
- Reservoir sampling of patient records

The graph and optimization options prompt for their input data. Graph vertices,
matching partitions, and returned item indices are zero-based. TSP distances
must be a complete nonnegative matrix and the route begins and ends at location
0. The project contains synthetic patient records; its algorithms are
demonstrations and are not medical decision-making tools.

## Web dashboard

The local HTML/CSS/JavaScript dashboard is in `MediSearch`. From that folder run
`npm start`, then open `http://127.0.0.1:3000`. Create an account to view the
corpus-backed patient dashboard and try KMP, Rabin-Karp, or suffix-array search.
See [MediSearch/README.md](MediSearch/README.md) for details. The web app is a
local project demo; do not use real patient data.