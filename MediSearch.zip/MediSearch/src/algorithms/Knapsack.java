package algorithms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class Knapsack {
    private Knapsack() {
    }

    public static Result solve(int[] weights, long[] values, int capacity) {
        if (weights == null || values == null || weights.length != values.length || capacity < 0)
            throw new IllegalArgumentException("Weights and values must have equal lengths and capacity must be nonnegative");
        for (int weight : weights) {
            if (weight < 0)
                throw new IllegalArgumentException("Item weights must be nonnegative");
        }

        long[] best = new long[capacity + 1];
        boolean[][] take = new boolean[weights.length][capacity + 1];
        for (int item = 0; item < weights.length; item++) {
            int weight = weights[item];
            for (int available = capacity; available >= weight; available--) {
                long candidate = Math.addExact(best[available - weight], values[item]);
                if (candidate > best[available]) {
                    best[available] = candidate;
                    take[item][available] = true;
                }
            }
        }

        List<Integer> selected = new ArrayList<>();
        int remaining = capacity;
        for (int item = weights.length - 1; item >= 0; item--) {
            if (take[item][remaining]) {
                selected.add(item);
                remaining -= weights[item];
            }
        }
        Collections.reverse(selected);
        return new Result(best[capacity], selected);
    }

    public static final class Result {
        private final long value;
        private final List<Integer> selectedItems;

        private Result(long value, List<Integer> selectedItems) {
            this.value = value;
            this.selectedItems = Collections.unmodifiableList(new ArrayList<>(selectedItems));
        }

        public long getValue() {
            return value;
        }

        public List<Integer> getSelectedItems() {
            return selectedItems;
        }
    }
}
