package algorithms;

import java.util.Objects;

public final class NeedlemanWunsch {
    private NeedlemanWunsch() {
    }

    public static Alignment align(String first, String second,
                                  int matchScore, int mismatchScore, int gapPenalty) {
        Objects.requireNonNull(first, "first");
        Objects.requireNonNull(second, "second");
        if (matchScore < 0 || mismatchScore > 0 || gapPenalty > 0)
            throw new IllegalArgumentException("Use a nonnegative match score and nonpositive mismatch/gap scores");

        int[][] scores = new int[first.length() + 1][second.length() + 1];
        for (int i = 1; i <= first.length(); i++)
            scores[i][0] = scores[i - 1][0] + gapPenalty;
        for (int j = 1; j <= second.length(); j++)
            scores[0][j] = scores[0][j - 1] + gapPenalty;

        for (int i = 1; i <= first.length(); i++) {
            for (int j = 1; j <= second.length(); j++) {
                int diagonal = scores[i - 1][j - 1]
                        + (first.charAt(i - 1) == second.charAt(j - 1) ? matchScore : mismatchScore);
                int deletion = scores[i - 1][j] + gapPenalty;
                int insertion = scores[i][j - 1] + gapPenalty;
                scores[i][j] = Math.max(diagonal, Math.max(deletion, insertion));
            }
        }

        StringBuilder alignedFirst = new StringBuilder();
        StringBuilder alignedSecond = new StringBuilder();
        int i = first.length();
        int j = second.length();
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && scores[i][j] == scores[i - 1][j - 1]
                    + (first.charAt(i - 1) == second.charAt(j - 1) ? matchScore : mismatchScore)) {
                alignedFirst.append(first.charAt(--i));
                alignedSecond.append(second.charAt(--j));
            } else if (i > 0 && scores[i][j] == scores[i - 1][j] + gapPenalty) {
                alignedFirst.append(first.charAt(--i));
                alignedSecond.append('-');
            } else {
                alignedFirst.append('-');
                alignedSecond.append(second.charAt(--j));
            }
        }

        return new Alignment(alignedFirst.reverse().toString(), alignedSecond.reverse().toString(),
                scores[first.length()][second.length()]);
    }

    public static final class Alignment {
        private final String first;
        private final String second;
        private final int score;

        private Alignment(String first, String second, int score) {
            this.first = first;
            this.second = second;
            this.score = score;
        }

        public String getFirst() {
            return first;
        }

        public String getSecond() {
            return second;
        }

        public int getScore() {
            return score;
        }
    }
}
