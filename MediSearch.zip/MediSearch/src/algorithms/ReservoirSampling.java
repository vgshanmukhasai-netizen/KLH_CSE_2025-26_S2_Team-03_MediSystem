package algorithms;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public final class ReservoirSampling {
    private ReservoirSampling() {
    }

    public static <T> List<T> sample(Iterable<T> items, int sampleSize) {
        return sample(items, sampleSize, new Random());
    }

    public static <T> List<T> sample(Iterable<T> items, int sampleSize, Random random) {
        Objects.requireNonNull(items, "items");
        Objects.requireNonNull(random, "random");
        if (sampleSize < 0)
            throw new IllegalArgumentException("Sample size must be nonnegative");

        List<T> reservoir = new ArrayList<>(Math.min(sampleSize, 1024));
        long seen = 0;
        for (T item : items) {
            seen++;
            if (reservoir.size() < sampleSize) {
                reservoir.add(item);
            } else if (sampleSize > 0) {
                long selected = random.nextLong(seen);
                if (selected < sampleSize)
                    reservoir.set((int) selected, item);
            }
        }
        return reservoir;
    }
}
