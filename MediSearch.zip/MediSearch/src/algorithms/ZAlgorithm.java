package algorithms;

import java.util.Objects;

public final class ZAlgorithm {
    private ZAlgorithm() {
    }

    public static boolean search(String text, String pattern) {
        Objects.requireNonNull(text, "text");
        Objects.requireNonNull(pattern, "pattern");
        if (pattern.isEmpty())
            return true;

        int patternLength = pattern.length();
        int textStart = patternLength + 1;
        int[] combined = new int[textStart + text.length()];
        for (int i = 0; i < patternLength; i++)
            combined[i] = pattern.charAt(i);
        combined[patternLength] = -1;
        for (int i = 0; i < text.length(); i++)
            combined[textStart + i] = text.charAt(i);

        int[] z = new int[combined.length];
        int left = 0;
        int right = 0;
        for (int i = 1; i < combined.length; i++) {
            if (i <= right)
                z[i] = Math.min(right - i + 1, z[i - left]);

            while (i + z[i] < combined.length && combined[z[i]] == combined[i + z[i]])
                z[i]++;

            if (i + z[i] - 1 > right) {
                left = i;
                right = i + z[i] - 1;
            }

            if (i >= textStart && z[i] >= patternLength)
                return true;
        }
        return false;
    }
}
