package algorithms;

import java.util.Objects;

public final class KMP {
    private KMP() {
    }

    public static boolean search(String text, String pattern) {
        Objects.requireNonNull(text, "text");
        Objects.requireNonNull(pattern, "pattern");
        if (pattern.isEmpty())
            return true;

        int[] prefix = new int[pattern.length()];
        for (int i = 1, matched = 0; i < pattern.length();) {
            if (pattern.charAt(i) == pattern.charAt(matched)) {
                prefix[i++] = ++matched;
            } else if (matched > 0) {
                matched = prefix[matched - 1];
            } else {
                prefix[i++] = 0;
            }
        }

        for (int i = 0, matched = 0; i < text.length();) {
            if (text.charAt(i) == pattern.charAt(matched)) {
                i++;
                matched++;
                if (matched == pattern.length())
                    return true;
            } else if (matched > 0) {
                matched = prefix[matched - 1];
            } else {
                i++;
            }
        }
        return false;
    }
}
