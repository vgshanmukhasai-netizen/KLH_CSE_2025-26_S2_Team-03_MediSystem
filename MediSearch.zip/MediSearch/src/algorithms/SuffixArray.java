package algorithms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public final class SuffixArray {
    private final String text;
    private final int[] suffixes;
    private final int[] lcp;

    public SuffixArray(String text) {
        this.text = Objects.requireNonNull(text, "text");
        this.suffixes = buildSuffixArray(text);
        this.lcp = buildLcpArray(text, suffixes);
    }

    public int length() {
        return suffixes.length;
    }

    public int[] getSuffixArray() {
        return suffixes.clone();
    }

    public int[] getLcpArray() {
        return lcp.clone();
    }

    public List<Integer> search(String pattern) {
        Objects.requireNonNull(pattern, "pattern");
        List<Integer> matches = new ArrayList<>();

        if (pattern.isEmpty()) {
            for (int i = 0; i <= text.length(); i++)
                matches.add(i);
            return matches;
        }

        int low = lowerBound(pattern);
        for (int i = low; i < suffixes.length && startsWith(suffixes[i], pattern); i++)
            matches.add(suffixes[i]);
        matches.sort(Integer::compareTo);
        return matches;
    }

    private int lowerBound(String pattern) {
        int low = 0;
        int high = suffixes.length;
        while (low < high) {
            int middle = low + (high - low) / 2;
            if (compareSuffixToPattern(suffixes[middle], pattern) < 0)
                low = middle + 1;
            else
                high = middle;
        }
        return low;
    }

    private int compareSuffixToPattern(int start, String pattern) {
        int length = Math.min(text.length() - start, pattern.length());
        for (int i = 0; i < length; i++) {
            int comparison = Character.compare(text.charAt(start + i), pattern.charAt(i));
            if (comparison != 0)
                return comparison;
        }
        return text.length() - start < pattern.length() ? -1 : 0;
    }

    private boolean startsWith(int start, String pattern) {
        return text.regionMatches(start, pattern, 0, pattern.length());
    }

    private static int[] buildSuffixArray(String text) {
        int size = text.length();
        int[] order = new int[size];
        int[] rank = new int[size];
        int[] nextRank = new int[size];

        for (int i = 0; i < size; i++) {
            order[i] = i;
            rank[i] = text.charAt(i);
        }

        for (int width = 1; width < size; width *= 2) {
            final int currentWidth = width;
            final int[] currentRank = rank;
            Integer[] boxedOrder = new Integer[size];
            for (int i = 0; i < size; i++)
                boxedOrder[i] = order[i];

            Arrays.sort(boxedOrder, (first, second) -> {
                int comparison = Integer.compare(currentRank[first], currentRank[second]);
                if (comparison != 0)
                    return comparison;
                int firstNext = first + currentWidth < size ? currentRank[first + currentWidth] : -1;
                int secondNext = second + currentWidth < size ? currentRank[second + currentWidth] : -1;
                return Integer.compare(firstNext, secondNext);
            });

            for (int i = 0; i < size; i++)
                order[i] = boxedOrder[i];

            if (size > 0)
                nextRank[order[0]] = 0;
            for (int i = 1; i < size; i++) {
                int previous = order[i - 1];
                int current = order[i];
                boolean different = rank[previous] != rank[current]
                        || (previous + width < size ? rank[previous + width] : -1)
                        != (current + width < size ? rank[current + width] : -1);
                nextRank[current] = nextRank[previous] + (different ? 1 : 0);
            }

            int[] swap = rank;
            rank = nextRank;
            nextRank = swap;
            if (rank[order[size - 1]] == size - 1)
                break;
            if (width > size / 2)
                break;
        }

        return order;
    }

    private static int[] buildLcpArray(String text, int[] suffixes) {
        int size = text.length();
        int[] lcp = new int[size];
        int[] inverse = new int[size];
        for (int i = 0; i < size; i++)
            inverse[suffixes[i]] = i;

        int common = 0;
        for (int start = 0; start < size; start++) {
            int position = inverse[start];
            if (position == 0)
                continue;
            int previous = suffixes[position - 1];
            while (start + common < size && previous + common < size
                    && text.charAt(start + common) == text.charAt(previous + common))
                common++;
            lcp[position] = common;
            if (common > 0)
                common--;
        }
        return lcp;
    }
}
