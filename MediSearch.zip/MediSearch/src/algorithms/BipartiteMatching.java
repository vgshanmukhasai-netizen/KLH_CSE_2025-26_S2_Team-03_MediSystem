package algorithms;

import java.util.ArrayList;
import java.util.List;

public final class BipartiteMatching {
    private BipartiteMatching() {
    }

    public static Matching maximumMatching(int leftSize, int rightSize, int[][] edges) {
        if (leftSize < 0 || rightSize < 0 || edges == null)
            throw new IllegalArgumentException("Partition sizes and edges must be nonnegative/non-null");

        List<List<Integer>> adjacency = new ArrayList<>(leftSize);
        for (int i = 0; i < leftSize; i++)
            adjacency.add(new ArrayList<>());
        for (int[] edge : edges) {
            if (edge == null || edge.length != 2
                    || edge[0] < 0 || edge[0] >= leftSize
                    || edge[1] < 0 || edge[1] >= rightSize)
                throw new IllegalArgumentException("Each edge must connect a valid left and right vertex");
            adjacency.get(edge[0]).add(edge[1]);
        }

        int[] rightPartner = new int[rightSize];
        java.util.Arrays.fill(rightPartner, -1);
        int count = 0;
        for (int left = 0; left < leftSize; left++) {
            if (augment(left, adjacency, rightPartner, new boolean[rightSize]))
                count++;
        }

        int[] leftPartner = new int[leftSize];
        java.util.Arrays.fill(leftPartner, -1);
        for (int right = 0; right < rightSize; right++) {
            if (rightPartner[right] >= 0)
                leftPartner[rightPartner[right]] = right;
        }
        return new Matching(leftPartner, rightPartner, count);
    }

    private static boolean augment(int left, List<List<Integer>> adjacency,
                                   int[] rightPartner, boolean[] visited) {
        for (int right : adjacency.get(left)) {
            if (visited[right])
                continue;
            visited[right] = true;
            if (rightPartner[right] == -1
                    || augment(rightPartner[right], adjacency, rightPartner, visited)) {
                rightPartner[right] = left;
                return true;
            }
        }
        return false;
    }

    public static final class Matching {
        private final int[] leftPartner;
        private final int[] rightPartner;
        private final int size;

        private Matching(int[] leftPartner, int[] rightPartner, int size) {
            this.leftPartner = leftPartner;
            this.rightPartner = rightPartner;
            this.size = size;
        }

        public int size() {
            return size;
        }

        public int[] getLeftPartners() {
            return leftPartner.clone();
        }

        public int[] getRightPartners() {
            return rightPartner.clone();
        }
    }
}
