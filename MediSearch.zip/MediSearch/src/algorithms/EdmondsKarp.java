package algorithms;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Queue;

public final class EdmondsKarp {
    private EdmondsKarp() {
    }

    public static Result maximumFlow(long[][] capacities, int source, int sink) {
        validate(capacities, source, sink);
        int vertices = capacities.length;
        long[][] residual = new long[vertices][vertices];
        for (int i = 0; i < vertices; i++)
            residual[i] = capacities[i].clone();

        long totalFlow = 0;
        int[] parent = new int[vertices];
        while (findPath(residual, source, sink, parent)) {
            long pathCapacity = Long.MAX_VALUE;
            for (int vertex = sink; vertex != source; vertex = parent[vertex])
                pathCapacity = Math.min(pathCapacity, residual[parent[vertex]][vertex]);

            for (int vertex = sink; vertex != source; vertex = parent[vertex]) {
                int previous = parent[vertex];
                residual[previous][vertex] -= pathCapacity;
                residual[vertex][previous] = Math.addExact(residual[vertex][previous], pathCapacity);
            }
            totalFlow = Math.addExact(totalFlow, pathCapacity);
        }

        boolean[] sourceSide = new boolean[vertices];
        Queue<Integer> queue = new ArrayDeque<>();
        sourceSide[source] = true;
        queue.add(source);
        while (!queue.isEmpty()) {
            int current = queue.remove();
            for (int next = 0; next < vertices; next++) {
                if (!sourceSide[next] && residual[current][next] > 0) {
                    sourceSide[next] = true;
                    queue.add(next);
                }
            }
        }
        return new Result(totalFlow, residual, sourceSide);
    }

    private static boolean findPath(long[][] residual, int source, int sink, int[] parent) {
        Arrays.fill(parent, -1);
        parent[source] = source;
        Queue<Integer> queue = new ArrayDeque<>();
        queue.add(source);
        while (!queue.isEmpty() && parent[sink] == -1) {
            int current = queue.remove();
            for (int next = 0; next < residual.length; next++) {
                if (parent[next] == -1 && residual[current][next] > 0) {
                    parent[next] = current;
                    queue.add(next);
                }
            }
        }
        return parent[sink] != -1;
    }

    private static void validate(long[][] capacities, int source, int sink) {
        if (capacities == null || capacities.length < 2)
            throw new IllegalArgumentException("At least two vertices are required");
        int vertices = capacities.length;
        if (source < 0 || source >= vertices || sink < 0 || sink >= vertices || source == sink)
            throw new IllegalArgumentException("Source and sink must be distinct valid vertices");
        for (long[] row : capacities) {
            if (row == null || row.length != vertices)
                throw new IllegalArgumentException("Capacity matrix must be square");
            for (long capacity : row) {
                if (capacity < 0)
                    throw new IllegalArgumentException("Capacities must be nonnegative");
            }
        }
    }

    public static final class Result {
        private final long flow;
        private final long[][] residual;
        private final boolean[] sourceSide;

        private Result(long flow, long[][] residual, boolean[] sourceSide) {
            this.flow = flow;
            this.residual = residual;
            this.sourceSide = sourceSide;
        }

        public long getFlow() {
            return flow;
        }

        public long[][] getResidualCapacities() {
            long[][] copy = new long[residual.length][];
            for (int i = 0; i < residual.length; i++)
                copy[i] = residual[i].clone();
            return copy;
        }

        public boolean[] getMinimumCutSourceSide() {
            return sourceSide.clone();
        }
    }
}
