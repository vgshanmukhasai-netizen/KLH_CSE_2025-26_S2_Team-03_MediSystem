package algorithms;

import java.util.ArrayList;
import java.util.List;

public final class VertexCoverApproximation {
    private VertexCoverApproximation() {
    }

    public static boolean[] twoApproximation(int vertexCount, int[][] edges) {
        if (vertexCount < 0 || edges == null)
            throw new IllegalArgumentException("Vertex count and edges must be nonnegative/non-null");
        List<int[]> validatedEdges = new ArrayList<>(edges.length);
        for (int[] edge : edges) {
            if (edge == null || edge.length != 2
                    || edge[0] < 0 || edge[0] >= vertexCount
                    || edge[1] < 0 || edge[1] >= vertexCount)
                throw new IllegalArgumentException("Each edge must contain two valid vertex indices");
            if (edge[0] != edge[1])
                validatedEdges.add(new int[] {edge[0], edge[1]});
        }

        boolean[] covered = new boolean[vertexCount];
        boolean[] cover = new boolean[vertexCount];
        for (int[] edge : validatedEdges) {
            if (!covered[edge[0]] && !covered[edge[1]]) {
                cover[edge[0]] = true;
                cover[edge[1]] = true;
                covered[edge[0]] = true;
                covered[edge[1]] = true;
            }
        }
        return cover;
    }
}
