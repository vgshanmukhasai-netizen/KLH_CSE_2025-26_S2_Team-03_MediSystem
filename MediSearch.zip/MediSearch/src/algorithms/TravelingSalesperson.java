package algorithms;

import java.util.Arrays;

public final class TravelingSalesperson {
    public static final int MAX_CITIES = 18;
    private static final long UNREACHABLE = Long.MAX_VALUE / 4;

    private TravelingSalesperson() {
    }

    public static Tour solve(long[][] distances) {
        validateDistances(distances);
        int cities = distances.length;
        if (cities > MAX_CITIES)
            throw new IllegalArgumentException("Exact TSP supports at most " + MAX_CITIES + " locations");
        if (cities == 1)
            return new Tour(new int[] {0, 0}, 0);

        int stateCount = 1 << cities;
        long[][] cost = new long[stateCount][cities];
        int[][] parent = new int[stateCount][cities];
        for (long[] row : cost)
            Arrays.fill(row, UNREACHABLE);
        for (int[] row : parent)
            Arrays.fill(row, -1);

        cost[1][0] = 0;
        for (int visited = 1; visited < stateCount; visited++) {
            if ((visited & 1) == 0)
                continue;
            for (int last = 0; last < cities; last++) {
                if ((visited & (1 << last)) == 0 || cost[visited][last] == UNREACHABLE)
                    continue;
                for (int next = 1; next < cities; next++) {
                    if ((visited & (1 << next)) != 0)
                        continue;
                    int nextVisited = visited | (1 << next);
                    long candidate = Math.addExact(cost[visited][last], distances[last][next]);
                    if (candidate < cost[nextVisited][next]) {
                        cost[nextVisited][next] = candidate;
                        parent[nextVisited][next] = last;
                    }
                }
            }
        }

        int allVisited = stateCount - 1;
        long bestCost = UNREACHABLE;
        int lastCity = -1;
        for (int last = 1; last < cities; last++) {
            if (cost[allVisited][last] == UNREACHABLE)
                continue;
            long candidate = Math.addExact(cost[allVisited][last], distances[last][0]);
            if (candidate < bestCost) {
                bestCost = candidate;
                lastCity = last;
            }
        }
        if (lastCity == -1)
            throw new IllegalArgumentException("No complete tour exists");

        int[] route = new int[cities + 1];
        int visited = allVisited;
        int current = lastCity;
        for (int position = cities - 1; position >= 1; position--) {
            route[position] = current;
            int previous = parent[visited][current];
            visited ^= 1 << current;
            current = previous;
        }
        route[0] = 0;
        route[cities] = 0;
        return new Tour(route, bestCost);
    }

    private static void validateDistances(long[][] distances) {
        if (distances == null || distances.length == 0)
            throw new IllegalArgumentException("At least one location is required");
        if (distances.length > MAX_CITIES)
            throw new IllegalArgumentException("Exact TSP supports at most " + MAX_CITIES + " locations");
        for (long[] row : distances) {
            if (row == null || row.length != distances.length)
                throw new IllegalArgumentException("Distance matrix must be square");
            for (long distance : row) {
                if (distance < 0)
                    throw new IllegalArgumentException("Distances must be nonnegative");
            }
        }
    }

    public static final class Tour {
        private final int[] route;
        private final long distance;

        private Tour(int[] route, long distance) {
            this.route = route;
            this.distance = distance;
        }

        public int[] getRoute() {
            return route.clone();
        }

        public long getDistance() {
            return distance;
        }
    }
}
