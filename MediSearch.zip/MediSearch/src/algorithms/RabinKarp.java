package algorithms;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public final class RabinKarp {
    private static final long BASE = 256;
    private static final long MODULUS = 1_000_000_007L;

    private RabinKarp() {
    }

    public static List<Integer> search(String text, String pattern) {
        Objects.requireNonNull(text, "text");
        Objects.requireNonNull(pattern, "pattern");
        List<Integer> matches = new ArrayList<>();

        if (pattern.length() > text.length())
            return matches;

        int patternLength = pattern.length();
        if (patternLength == 0) {
            for (int i = 0; i <= text.length(); i++)
                matches.add(i);
            return matches;
        }

        long highestPower = 1;
        for (int i = 1; i < patternLength; i++)
            highestPower = highestPower * BASE % MODULUS;

        long patternHash = 0;
        long windowHash = 0;
        for (int i = 0; i < patternLength; i++) {
            patternHash = (patternHash * BASE + pattern.charAt(i)) % MODULUS;
            windowHash = (windowHash * BASE + text.charAt(i)) % MODULUS;
        }

        for (int start = 0; start <= text.length() - patternLength; start++) {
            if (patternHash == windowHash
                    && text.regionMatches(start, pattern, 0, patternLength))
                matches.add(start);

            if (start < text.length() - patternLength) {
                long leading = text.charAt(start) * highestPower % MODULUS;
                windowHash = (windowHash - leading + MODULUS) % MODULUS;
                windowHash = (windowHash * BASE + text.charAt(start + patternLength)) % MODULUS;
            }
        }

        return matches;
    }
}
