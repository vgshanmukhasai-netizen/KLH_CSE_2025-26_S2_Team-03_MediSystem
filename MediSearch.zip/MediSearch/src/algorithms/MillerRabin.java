package algorithms;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Objects;
import java.util.Random;

public final class MillerRabin {
    private static final BigInteger TWO = BigInteger.valueOf(2);
    private static final BigInteger THREE = BigInteger.valueOf(3);

    private MillerRabin() {
    }

    public static boolean isProbablyPrime(BigInteger number, int rounds) {
        return isProbablyPrime(number, rounds, new SecureRandom());
    }

    public static boolean isProbablyPrime(BigInteger number, int rounds, Random random) {
        Objects.requireNonNull(number, "number");
        Objects.requireNonNull(random, "random");
        if (rounds < 1)
            throw new IllegalArgumentException("At least one Miller-Rabin round is required");
        if (number.compareTo(TWO) < 0)
            return false;
        if (number.equals(TWO) || number.equals(THREE))
            return true;
        if (!number.testBit(0))
            return false;

        BigInteger oddPart = number.subtract(BigInteger.ONE);
        int powersOfTwo = oddPart.getLowestSetBit();
        oddPart = oddPart.shiftRight(powersOfTwo);
        BigInteger exponent = oddPart;
        BigInteger numberMinusOne = number.subtract(BigInteger.ONE);
        BigInteger maxBase = number.subtract(THREE);

        for (int round = 0; round < rounds; round++) {
            BigInteger base = new BigInteger(number.bitLength(), random)
                    .mod(maxBase).add(TWO);
            BigInteger witness = base.modPow(exponent, number);
            if (witness.equals(BigInteger.ONE) || witness.equals(numberMinusOne))
                continue;

            boolean probablyPrime = false;
            for (int step = 1; step < powersOfTwo; step++) {
                witness = witness.multiply(witness).mod(number);
                if (witness.equals(numberMinusOne)) {
                    probablyPrime = true;
                    break;
                }
                if (witness.equals(BigInteger.ONE))
                    return false;
            }
            if (!probablyPrime)
                return false;
        }
        return true;
    }
}
