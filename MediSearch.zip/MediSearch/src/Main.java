import algorithms.BipartiteMatching;
import algorithms.EdmondsKarp;
import algorithms.Knapsack;
import algorithms.MillerRabin;
import algorithms.NeedlemanWunsch;
import algorithms.TravelingSalesperson;
import algorithms.VertexCoverApproximation;
import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final int MAX_GRAPH_VERTICES = 500;
    private static final int MAX_EDGES = 100_000;
    private static final int MAX_ITEMS = 500;
    private static final int MAX_KNAPSACK_CAPACITY = 10_000;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SearchEngine engine = new SearchEngine();

        while (true) {
            printMenu();
            int choice = readInt(scanner, "Choice: ", 1, 18);
            if (choice == 18)
                break;

            switch (choice) {
                case 1:
                    engine.searchKMP(readLine(scanner, "Enter Query: "));
                    break;
                case 2:
                    engine.searchZ(readLine(scanner, "Enter Query: "));
                    break;
                case 3:
                    engine.searchTrie(readLine(scanner, "Enter Disease: "));
                    break;
                case 4:
                    engine.searchEditDistance(readLine(scanner, "Enter Disease Query: "));
                    break;
                case 5:
                    engine.searchAho(readLine(scanner, "Enter Query: "));
                    break;
                case 6:
                    engine.searchSmithWaterman(readLine(scanner, "Enter Query: "));
                    break;
                case 7:
                    engine.searchOptimalBST(readLine(scanner, "Enter Disease: "));
                    break;
                case 8:
                    engine.searchRabinKarp(readLine(scanner, "Enter Query: "));
                    break;
                case 9:
                    engine.searchSuffixArray(readLine(scanner, "Enter Query: "));
                    break;
                case 10:
                    runNeedlemanWunsch(scanner);
                    break;
                case 11:
                    runTravelingSalesperson(scanner);
                    break;
                case 12:
                    runBipartiteMatching(scanner);
                    break;
                case 13:
                    runEdmondsKarp(scanner);
                    break;
                case 14:
                    runVertexCover(scanner);
                    break;
                case 15:
                    runKnapsack(scanner);
                    break;
                case 16:
                    runMillerRabin(scanner);
                    break;
                case 17:
                    runReservoirSampling(scanner, engine);
                    break;
                default:
                    throw new IllegalStateException("Unexpected menu choice: " + choice);
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n===== MEDISEARCH =====");
        System.out.println("1. KMP Search");
        System.out.println("2. Z Algorithm Search");
        System.out.println("3. Trie Disease Search");
        System.out.println("4. Edit Distance Search");
        System.out.println("5. Aho-Corasick Search");
        System.out.println("6. Smith-Waterman Search");
        System.out.println("7. Optimal BST Disease Search");
        System.out.println("8. Rabin-Karp Search");
        System.out.println("9. Suffix Array Search");
        System.out.println("10. Needleman-Wunsch Sequence Alignment");
        System.out.println("11. TSP Ambulance Route");
        System.out.println("12. Bipartite Matching");
        System.out.println("13. Edmonds-Karp Maximum Flow");
        System.out.println("14. Vertex Cover Approximation");
        System.out.println("15. 0/1 Knapsack");
        System.out.println("16. Miller-Rabin Primality Test");
        System.out.println("17. Reservoir Sample Patients");
        System.out.println("18. Exit");
    }

    private static void runNeedlemanWunsch(Scanner scanner) {
        String first = readLine(scanner, "Enter first sequence: ");
        String second = readLine(scanner, "Enter second sequence: ");
        int match = readInt(scanner, "Match score (0..1000): ", 0, 1000);
        int mismatch = readInt(scanner, "Mismatch score (-1000..0): ", -1000, 0);
        int gap = readInt(scanner, "Gap penalty (-1000..0): ", -1000, 0);
        NeedlemanWunsch.Alignment result =
                NeedlemanWunsch.align(first, second, match, mismatch, gap);
        System.out.println("Aligned first:  " + result.getFirst());
        System.out.println("Aligned second: " + result.getSecond());
        System.out.println("Alignment score: " + result.getScore());
    }

    private static void runTravelingSalesperson(Scanner scanner) {
        int cities = readInt(scanner, "Number of locations (1.."
                + TravelingSalesperson.MAX_CITIES + "): ", 1, TravelingSalesperson.MAX_CITIES);
        long[][] distances = new long[cities][cities];
        System.out.println("Enter the complete distance matrix (nonnegative integers); location 0 is the ambulance base.");
        for (int from = 0; from < cities; from++) {
            for (int to = 0; to < cities; to++)
                distances[from][to] = readLong(scanner,
                        "Distance " + from + " -> " + to + ": ", 0, Long.MAX_VALUE / 4);
        }
        TravelingSalesperson.Tour tour = TravelingSalesperson.solve(distances);
        System.out.println("Route: " + formatRoute(tour.getRoute()));
        System.out.println("Total distance: " + tour.getDistance());
    }

    private static void runBipartiteMatching(Scanner scanner) {
        int left = readInt(scanner, "Number of care teams (0.."
                + MAX_GRAPH_VERTICES + "): ", 0, MAX_GRAPH_VERTICES);
        int right = readInt(scanner, "Number of patients/appointments (0.."
                + MAX_GRAPH_VERTICES + "): ", 0, MAX_GRAPH_VERTICES);
        int maximumPairs = left == 0 || right == 0 ? 0 : MAX_EDGES;
        int edgeCount = readInt(scanner, "Number of eligible team-patient pairs (0.."
                + maximumPairs + "): ", 0, maximumPairs);
        int[][] edges = new int[edgeCount][2];
        for (int i = 0; i < edgeCount; i++) {
            edges[i][0] = readInt(scanner, "Pair " + (i + 1) + " team index (0-based): ", 0,
                    Math.max(0, left - 1));
            edges[i][1] = readInt(scanner, "Pair " + (i + 1) + " patient index (0-based): ", 0,
                    Math.max(0, right - 1));
        }
        BipartiteMatching.Matching matching =
                BipartiteMatching.maximumMatching(left, right, edges);
        System.out.println("Maximum assignments: " + matching.size());
        int[] partners = matching.getLeftPartners();
        for (int team = 0; team < partners.length; team++) {
            if (partners[team] >= 0)
                System.out.println("Team " + team + " -> Patient " + partners[team]);
        }
    }

    private static void runEdmondsKarp(Scanner scanner) {
        int vertices = readInt(scanner, "Number of network vertices (2.."
                + MAX_GRAPH_VERTICES + "): ", 2, MAX_GRAPH_VERTICES);
        long[][] capacities = new long[vertices][vertices];
        System.out.println("Enter the directed capacity matrix (nonnegative; use 0 for no edge).");
        for (int from = 0; from < vertices; from++) {
            for (int to = 0; to < vertices; to++)
                capacities[from][to] = readLong(scanner,
                        "Capacity " + from + " -> " + to + ": ", 0, Long.MAX_VALUE / 4);
        }
        int source = readInt(scanner, "Source vertex (0-based): ", 0, vertices - 1);
        int sink = readInt(scanner, "Sink vertex (0-based): ", 0, vertices - 1);
        while (sink == source) {
            System.out.println("Source and sink must be different.");
            sink = readInt(scanner, "Sink vertex (0-based): ", 0, vertices - 1);
        }
        EdmondsKarp.Result result = EdmondsKarp.maximumFlow(capacities, source, sink);
        System.out.println("Maximum flow: " + result.getFlow());
        boolean[] sourceSide = result.getMinimumCutSourceSide();
        System.out.print("Minimum cut source side: ");
        for (int vertex = 0; vertex < sourceSide.length; vertex++) {
            if (sourceSide[vertex])
                System.out.print(vertex + " ");
        }
        System.out.println();
    }

    private static void runVertexCover(Scanner scanner) {
        int vertices = readInt(scanner, "Number of graph vertices (0.."
                + MAX_GRAPH_VERTICES + "): ", 0, MAX_GRAPH_VERTICES);
        int maximumEdges = vertices == 0 ? 0 : MAX_EDGES;
        int edgeCount = readInt(scanner, "Number of undirected edges (0.."
                + maximumEdges + "): ", 0, maximumEdges);
        int[][] edges = readEdges(scanner, edgeCount, vertices, "edge");
        boolean[] cover = VertexCoverApproximation.twoApproximation(vertices, edges);
        System.out.println("Approximate vertex cover (0-based): " + indicesOf(cover));
        System.out.println("Cover size: " + countTrue(cover));
        System.out.println("Guarantee: at most twice the minimum cover size.");
    }

    private static void runKnapsack(Scanner scanner) {
        int itemCount = readInt(scanner, "Number of items (0.."
                + MAX_ITEMS + "): ", 0, MAX_ITEMS);
        int capacity = readInt(scanner, "Capacity (0.."
                + MAX_KNAPSACK_CAPACITY + "): ", 0, MAX_KNAPSACK_CAPACITY);
        int[] weights = new int[itemCount];
        long[] values = new long[itemCount];
        for (int item = 0; item < itemCount; item++) {
            weights[item] = readInt(scanner, "Item " + item + " weight: ", 0,
                    MAX_KNAPSACK_CAPACITY);
            values[item] = readLong(scanner, "Item " + item + " value: ",
                    0, Long.MAX_VALUE / 4);
        }
        Knapsack.Result result = Knapsack.solve(weights, values, capacity);
        System.out.println("Maximum value: " + result.getValue());
        System.out.println("Selected item indices (0-based): " + result.getSelectedItems());
    }

    private static void runMillerRabin(Scanner scanner) {
        BigInteger number;
        while (true) {
            String input = readLine(scanner, "Enter an integer to test: ");
            try {
                number = new BigInteger(input);
                break;
            } catch (NumberFormatException exception) {
                System.out.println("Please enter a valid integer.");
            }
        }
        int rounds = readInt(scanner, "Randomized test rounds (1..100): ", 1, 100);
        System.out.println(number + (MillerRabin.isProbablyPrime(number, rounds)
                ? " is probably prime." : " is composite."));
    }

    private static void runReservoirSampling(Scanner scanner, SearchEngine engine) {
        int sampleSize = readInt(scanner, "Number of patient records to sample (0.."
                + engine.patientCount() + "): ", 0, engine.patientCount());
        List<Patient> sample = engine.samplePatients(sampleSize);
        System.out.println("Reservoir sample (" + sample.size() + " records):");
        for (Patient patient : sample)
            System.out.println(patient);
    }

    private static int[][] readEdges(Scanner scanner, int edgeCount, int vertices, String label) {
        int[][] edges = new int[edgeCount][2];
        for (int i = 0; i < edgeCount; i++) {
            edges[i][0] = readInt(scanner, label + " " + (i + 1) + " first vertex (0-based): ",
                    0, Math.max(0, vertices - 1));
            edges[i][1] = readInt(scanner, label + " " + (i + 1) + " second vertex (0-based): ",
                    0, Math.max(0, vertices - 1));
        }
        return edges;
    }

    private static int readInt(Scanner scanner, String prompt, int minimum, int maximum) {
        while (true) {
            String input = readLine(scanner, prompt);
            try {
                int value = Integer.parseInt(input);
                if (value >= minimum && value <= maximum)
                    return value;
            } catch (NumberFormatException exception) {
                // Report malformed numeric input below.
            }
            System.out.println("Enter an integer from " + minimum + " to " + maximum + ".");
        }
    }

    private static long readLong(Scanner scanner, String prompt, long minimum, long maximum) {
        while (true) {
            String input = readLine(scanner, prompt);
            try {
                long value = Long.parseLong(input);
                if (value >= minimum && value <= maximum)
                    return value;
            } catch (NumberFormatException exception) {
                // Report malformed numeric input below.
            }
            System.out.println("Enter an integer from " + minimum + " to " + maximum + ".");
        }
    }

    private static String readLine(Scanner scanner, String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static String formatRoute(int[] route) {
        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < route.length; i++) {
            if (i > 0)
                formatted.append(" -> ");
            formatted.append(route[i]);
        }
        return formatted.toString();
    }

    private static String indicesOf(boolean[] selected) {
        StringBuilder indices = new StringBuilder("[");
        boolean first = true;
        for (int i = 0; i < selected.length; i++) {
            if (selected[i]) {
                if (!first)
                    indices.append(", ");
                indices.append(i);
                first = false;
            }
        }
        return indices.append(']').toString();
    }

    private static int countTrue(boolean[] values) {
        int count = 0;
        for (boolean value : values) {
            if (value)
                count++;
        }
        return count;
    }
}
