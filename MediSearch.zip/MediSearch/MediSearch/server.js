const crypto = require("node:crypto");
const fs = require("node:fs/promises");
const path = require("node:path");
const { promisify } = require("node:util");
const express = require("express");

const scrypt = promisify(crypto.scrypt);
const app = express();
const PORT = Number(process.env.PORT || 3000);
const SESSION_DURATION_MS = 8 * 60 * 60 * 1000;
const PASSWORD_KEY_LENGTH = 64;
const AUTH_COOKIE = "medisearch_session";
const accountsPath = path.join(__dirname, "data", "accounts.json");
const corpusPath = path.join(__dirname, "..", "src", "corpus_txt");
const sessions = new Map();

let accounts = [];
let accountWriteQueue = Promise.resolve();
let patients = [];

app.disable("x-powered-by");
app.use((request, response, next) => {
    response.set({
        "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
        "X-Content-Type-Options": "nosniff",
        "Referrer-Policy": "strict-origin-when-cross-origin",
        "Permissions-Policy": "camera=(), microphone=(), geolocation=()"
    });
    if (["POST", "PUT", "PATCH", "DELETE"].includes(request.method)
            && request.headers.origin) {
        let origin;
        try {
            origin = new URL(request.headers.origin);
        } catch {
            response.status(403).json({ error: "This request origin is not allowed." });
            return;
        }
        if (origin.host !== request.headers.host) {
            response.status(403).json({ error: "This request origin is not allowed." });
            return;
        }
    }
    next();
});
app.use(express.json({ limit: "10kb", strict: true }));
app.use(express.static(path.join(__dirname, "public"), {
    index: "index.html",
    fallthrough: true,
    dotfiles: "deny"
}));

function parsePatientFile(contents, filename) {
    const record = {};
    for (const line of contents.split(/\r?\n/)) {
        const separator = line.indexOf(":");
        if (separator < 0)
            continue;
        const key = line.slice(0, separator).trim();
        const value = line.slice(separator + 1).trim();
        if (key && value)
            record[key] = value;
    }

    const required = ["Patient_ID", "Name", "Age", "Disease", "Symptoms", "Severity"];
    for (const key of required) {
        if (!record[key])
            throw new Error(`Patient record "${filename}" is missing ${key}.`);
    }

    const age = Number(record.Age);
    if (!Number.isInteger(age) || age < 0)
        throw new Error(`Patient record "${filename}" has an invalid age.`);

    return {
        id: record.Patient_ID,
        name: record.Name,
        age,
        disease: record.Disease,
        symptoms: record.Symptoms,
        severity: record.Severity,
        department: record.Department || "Unassigned",
        status: record.Status || "Unknown",
        admissionDate: record.Admission_Date || "",
        details: record
    };
}

async function loadPatients() {
    const entries = await fs.readdir(corpusPath, { withFileTypes: true });
    const records = [];
    for (const entry of entries) {
        if (!entry.isFile() || !entry.name.toLowerCase().endsWith(".txt"))
            continue;
        const contents = await fs.readFile(path.join(corpusPath, entry.name), "utf8");
        records.push(parsePatientFile(contents, entry.name));
    }
    records.sort((first, second) => first.id.localeCompare(second.id, undefined, { numeric: true }));
    return records;
}

async function loadAccounts() {
    await fs.mkdir(path.dirname(accountsPath), { recursive: true });
    try {
        const saved = JSON.parse(await fs.readFile(accountsPath, "utf8"));
        if (!Array.isArray(saved)
                || saved.some(account => !account
                    || typeof account.name !== "string"
                    || typeof account.email !== "string"
                    || typeof account.salt !== "string"
                    || typeof account.passwordHash !== "string")) {
            throw new Error("The local accounts file has an invalid format.");
        }
        return saved;
    } catch (error) {
        if (error.code !== "ENOENT")
            throw error;
        await fs.writeFile(accountsPath, "[]\n", { flag: "wx" });
        return [];
    }
}

async function persistAccounts(nextAccounts) {
    const temporaryPath = `${accountsPath}.${crypto.randomUUID()}.tmp`;
    try {
        await fs.writeFile(temporaryPath, `${JSON.stringify(nextAccounts, null, 2)}\n`, {
            encoding: "utf8",
            flag: "wx"
        });
        await fs.rename(temporaryPath, accountsPath);
    } catch (error) {
        await fs.rm(temporaryPath, { force: true });
        throw error;
    }
}

function queueAccountWrite(operation) {
    const result = accountWriteQueue.then(operation);
    accountWriteQueue = result.catch(() => {});
    return result;
}

function normalizeEmail(email) {
    return email.trim().toLowerCase();
}

function validEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function publicAccount(account) {
    return { name: account.name, email: account.email };
}

function setSessionCookie(response, token) {
    const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
    response.setHeader("Set-Cookie",
        `${AUTH_COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${SESSION_DURATION_MS / 1000}${secure}`);
}

function clearSessionCookie(response) {
    const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
    response.setHeader("Set-Cookie",
        `${AUTH_COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure}`);
}

function currentSession(request) {
    const cookieHeader = request.headers.cookie || "";
    const cookie = cookieHeader.split(";").map(part => part.trim())
        .find(part => part.startsWith(`${AUTH_COOKIE}=`));
    if (!cookie)
        return null;

    const token = cookie.slice(AUTH_COOKIE.length + 1);
    const session = sessions.get(token);
    if (!session)
        return null;
    if (session.expiresAt <= Date.now()) {
        sessions.delete(token);
        return null;
    }
    return session;
}

function requireSession(request, response, next) {
    const session = currentSession(request);
    if (!session) {
        clearSessionCookie(response);
        response.status(401).json({ error: "Please sign in to continue." });
        return;
    }
    request.account = session.account;
    next();
}

function createSession(account, response) {
    const token = crypto.randomBytes(32).toString("base64url");
    sessions.set(token, { account, expiresAt: Date.now() + SESSION_DURATION_MS });
    setSessionCookie(response, token);
}

function kmpContains(text, pattern) {
    if (!pattern)
        return true;
    const prefix = new Array(pattern.length).fill(0);
    for (let index = 1, matched = 0; index < pattern.length;) {
        if (pattern[index] === pattern[matched])
            prefix[index++] = ++matched;
        else if (matched > 0)
            matched = prefix[matched - 1];
        else
            prefix[index++] = 0;
    }

    for (let index = 0, matched = 0; index < text.length;) {
        if (text[index] === pattern[matched]) {
            index++;
            matched++;
            if (matched === pattern.length)
                return true;
        } else if (matched > 0) {
            matched = prefix[matched - 1];
        } else {
            index++;
        }
    }
    return false;
}

function rabinKarpContains(text, pattern) {
    if (!pattern)
        return true;
    if (pattern.length > text.length)
        return false;

    const base = 256;
    const modulus = 1_000_000_007;
    let leadingPower = 1;
    for (let index = 1; index < pattern.length; index++)
        leadingPower = leadingPower * base % modulus;

    let patternHash = 0;
    let windowHash = 0;
    for (let index = 0; index < pattern.length; index++) {
        patternHash = (patternHash * base + pattern.charCodeAt(index)) % modulus;
        windowHash = (windowHash * base + text.charCodeAt(index)) % modulus;
    }

    for (let start = 0; start <= text.length - pattern.length; start++) {
        if (patternHash === windowHash && text.startsWith(pattern, start))
            return true;
        if (start < text.length - pattern.length) {
            const leading = text.charCodeAt(start) * leadingPower % modulus;
            windowHash = (windowHash - leading + modulus) % modulus;
            windowHash = (windowHash * base + text.charCodeAt(start + pattern.length)) % modulus;
        }
    }
    return false;
}

function suffixArrayContains(text, pattern) {
    if (!pattern)
        return true;
    const suffixes = Array.from({ length: text.length }, (_, index) => index);
    suffixes.sort((first, second) => {
        const firstSuffix = text.slice(first);
        const secondSuffix = text.slice(second);
        return firstSuffix < secondSuffix ? -1 : firstSuffix > secondSuffix ? 1 : 0;
    });

    let low = 0;
    let high = suffixes.length;
    while (low < high) {
        const middle = low + Math.floor((high - low) / 2);
        const suffix = text.slice(suffixes[middle]);
        if (suffix < pattern)
            low = middle + 1;
        else
            high = middle;
    }
    return low < suffixes.length && text.startsWith(pattern, suffixes[low]);
}

const searchMethods = {
    kmp: kmpContains,
    "rabin-karp": rabinKarpContains,
    "suffix-array": suffixArrayContains
};

function patientSearchText(patient) {
    return Object.values(patient.details).join(" ").toLowerCase();
}

app.get("/api/session", (request, response) => {
    const session = currentSession(request);
    response.json({ user: session ? publicAccount(session.account) : null });
});

app.post("/api/auth/signup", async (request, response, next) => {
    const body = request.body || {};
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? normalizeEmail(body.email) : "";
    const password = typeof body.password === "string" ? body.password : "";

    if (name.length < 2 || name.length > 60) {
        response.status(400).json({ error: "Enter a name between 2 and 60 characters." });
        return;
    }
    if (!validEmail(email) || email.length > 254) {
        response.status(400).json({ error: "Enter a valid email address." });
        return;
    }
    if (password.length < 10 || password.length > 128) {
        response.status(400).json({ error: "Use a password between 10 and 128 characters." });
        return;
    }

    try {
        const account = await queueAccountWrite(async () => {
            if (accounts.some(existing => existing.email === email))
                return null;
            const salt = crypto.randomBytes(16);
            const passwordHash = await scrypt(password, salt, PASSWORD_KEY_LENGTH);
            const created = {
                name,
                email,
                salt: salt.toString("hex"),
                passwordHash: passwordHash.toString("hex")
            };
            const nextAccounts = [...accounts, created];
            await persistAccounts(nextAccounts);
            accounts = nextAccounts;
            return created;
        });
        if (!account) {
            response.status(409).json({ error: "An account with this email already exists. Try signing in." });
            return;
        }
        createSession(account, response);
        response.status(201).json({ user: publicAccount(account) });
    } catch (error) {
        next(error);
    }
});

app.post("/api/auth/login", async (request, response, next) => {
    const body = request.body || {};
    const email = typeof body.email === "string" ? normalizeEmail(body.email) : "";
    const password = typeof body.password === "string" ? body.password : "";
    if (!validEmail(email) || password.length === 0 || password.length > 128) {
        response.status(400).json({ error: "Enter your email and password." });
        return;
    }

    try {
        const account = accounts.find(existing => existing.email === email);
        if (!account) {
            response.status(401).json({ error: "Email or password is incorrect." });
            return;
        }
        const expected = Buffer.from(account.passwordHash, "hex");
        const actual = await scrypt(password, Buffer.from(account.salt, "hex"), PASSWORD_KEY_LENGTH);
        if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) {
            response.status(401).json({ error: "Email or password is incorrect." });
            return;
        }
        createSession(account, response);
        response.json({ user: publicAccount(account) });
    } catch (error) {
        next(error);
    }
});

app.post("/api/auth/logout", (request, response) => {
    const session = currentSession(request);
    if (session) {
        const token = (request.headers.cookie || "").split(";").map(part => part.trim())
            .find(part => part.startsWith(`${AUTH_COOKIE}=`))?.slice(AUTH_COOKIE.length + 1);
        if (token)
            sessions.delete(token);
    }
    clearSessionCookie(response);
    response.status(204).end();
});

app.get("/api/dashboard", requireSession, (request, response) => {
    const severityCounts = {};
    const diseaseCounts = {};
    const departmentCounts = {};
    for (const patient of patients) {
        severityCounts[patient.severity] = (severityCounts[patient.severity] || 0) + 1;
        diseaseCounts[patient.disease] = (diseaseCounts[patient.disease] || 0) + 1;
        departmentCounts[patient.department] = (departmentCounts[patient.department] || 0) + 1;
    }

    const severityRank = { mild: 0, low: 0, moderate: 1, medium: 1, severe: 2, high: 2, critical: 3 };
    const severityOrder = Object.keys(severityCounts).sort((first, second) => {
        const firstRank = severityRank[first.toLowerCase()] ?? 4;
        const secondRank = severityRank[second.toLowerCase()] ?? 4;
        return firstRank - secondRank || first.localeCompare(second);
    });
    const topDiseases = Object.entries(diseaseCounts)
        .sort((first, second) => second[1] - first[1] || first[0].localeCompare(second[0]))
        .slice(0, 5)
        .map(([name, count]) => ({ name, count }));

    response.json({
        patientCount: patients.length,
        urgentCount: patients.filter(patient => {
            const severity = patient.severity.toLowerCase();
            return severity === "critical" || severity === "severe" || severity === "high";
        }).length,
        departmentCount: Object.keys(departmentCounts).length,
        severityCounts,
        severityOrder,
        topDiseases,
        user: publicAccount(request.account)
    });
});

app.get("/api/patients", requireSession, (request, response) => {
    const query = typeof request.query.q === "string" ? request.query.q.trim().toLowerCase() : "";
    const method = typeof request.query.method === "string" ? request.query.method : "kmp";
    const disease = typeof request.query.disease === "string" ? request.query.disease.trim().toLowerCase() : "";
    const status = typeof request.query.status === "string" ? request.query.status.trim().toLowerCase() : "";
    if (query.length > 100) {
        response.status(400).json({ error: "Search terms must be 100 characters or fewer." });
        return;
    }
    if (!Object.hasOwn(searchMethods, method)) {
        response.status(400).json({ error: "Select KMP, Rabin-Karp, or Suffix Array search." });
        return;
    }

    const normalizedQuery = query.toLowerCase();
    const results = patients.filter(patient => {
        if (disease && patient.disease.toLowerCase() !== disease)
            return false;
        if (status && patient.status.toLowerCase() !== status)
            return false;
        return !normalizedQuery
            || searchMethods[method](patientSearchText(patient), normalizedQuery);
    });
    response.json({ patients: results });
});

app.use((error, request, response, next) => {
    if (response.headersSent) {
        next(error);
        return;
    }
    if (error.type === "entity.parse.failed") {
        response.status(400).json({ error: "The request body must be valid JSON." });
        return;
    }
    if (error.type === "entity.too.large") {
        response.status(413).json({ error: "The request is too large." });
        return;
    }
    console.error("MediSearch request failed:", error.message);
    response.status(500).json({ error: "Something went wrong. Please try again." });
});

async function start() {
    accounts = await loadAccounts();
    patients = await loadPatients();
    const server = app.listen(PORT, "127.0.0.1", () => {
        console.log(`MediSearch is available at http://127.0.0.1:${PORT}`);
        console.log(`Loaded ${patients.length} patient records.`);
    });
    server.on("error", error => {
        console.error("Unable to start MediSearch:", error.message);
        process.exitCode = 1;
    });
}

start().catch(error => {
    console.error("Unable to initialize MediSearch:", error.message);
    process.exitCode = 1;
});
