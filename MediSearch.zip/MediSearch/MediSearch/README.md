# MediSearch web workspace

The local web application provides account sign-up/sign-in, an authenticated
dashboard, patient-record filters, and KMP, Rabin-Karp, and suffix-array search.
It reads the synthetic records directly from `..\src\corpus_txt`. Search covers
every field in a patient file, and **View record** opens the complete set of
fields from that file.

## Run locally

Use Node.js 18 or newer. From this folder:

```powershell
npm start
```

Open <http://127.0.0.1:3000>. Create an account on the sign-in page, then browse
the dashboard and patient directory. The Node dependencies are already listed
in `package.json`; if this is a fresh checkout, install them first with
`npm install`.

Accounts are saved locally in `data\accounts.json`. Passwords are stored as
scrypt hashes, not plain text. Sessions are held in server memory and end when
the server restarts or the browser signs out. The server listens on loopback
only; this is a local project demonstration, not a production authentication
service.

Use only synthetic patient records. Do not put real patient or account data in
this demo. Patient record details contain information such as emergency
contacts, allergies, and medication, so only use the local synthetic corpus.
This project is not clinical decision-support software.
