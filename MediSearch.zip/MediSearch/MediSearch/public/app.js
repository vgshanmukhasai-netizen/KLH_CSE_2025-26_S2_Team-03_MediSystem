const authScreen = document.querySelector("#auth-screen");
const appScreen = document.querySelector("#app-screen");
const authForm = document.querySelector("#auth-form");
const authMessage = document.querySelector("#auth-message");
const authTitle = document.querySelector("#auth-title");
const authSubtitle = document.querySelector("#auth-subtitle");
const authSubmit = document.querySelector("#auth-submit");
const nameField = document.querySelector("#name-field");
const nameInput = document.querySelector("#name");
const emailInput = document.querySelector("#email");
const passwordInput = document.querySelector("#password");
const passwordHint = document.querySelector("#password-hint");
const patientSearch = document.querySelector("#patient-search");
const searchMethod = document.querySelector("#search-method");
const diseaseFilter = document.querySelector("#disease-filter");
const statusFilter = document.querySelector("#status-filter");

let authMode = "login";
let activeView = "overview";
let patientRecords = [];
let searchRequestId = 0;
let searchTimer;
let toastTimer;

async function api(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            ...(options.body ? { "Content-Type": "application/json" } : {}),
            ...options.headers
        },
        credentials: "same-origin"
    });
    if (response.status === 204)
        return null;

    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
        if (response.status === 401 && !url.endsWith("/api/auth/login")
                && !url.endsWith("/api/auth/signup")) {
            showAuth();
            throw new Error("Your session has expired. Sign in again to continue.");
        }
        throw new Error(result.error || "The request could not be completed.");
    }
    return result;
}

function showAuth(message = "") {
    appScreen.classList.add("is-hidden");
    authScreen.classList.remove("is-hidden");
    setAuthMode("login");
    if (message)
        setAuthMessage(message, "error");
}

function setAuthMode(mode) {
    authMode = mode;
    const signingUp = mode === "signup";
    document.querySelector("#login-tab").classList.toggle("is-active", !signingUp);
    document.querySelector("#signup-tab").classList.toggle("is-active", signingUp);
    document.querySelector("#login-tab").setAttribute("aria-selected", String(!signingUp));
    document.querySelector("#signup-tab").setAttribute("aria-selected", String(signingUp));
    nameField.classList.toggle("is-hidden", !signingUp);
    nameInput.required = signingUp;
    nameInput.autocomplete = signingUp ? "name" : "off";
    passwordInput.autocomplete = signingUp ? "new-password" : "current-password";
    passwordHint.classList.toggle("is-hidden", !signingUp);
    passwordInput.placeholder = signingUp ? "At least 10 characters" : "Enter your password";
    authTitle.textContent = signingUp ? "Create your account" : "Welcome back";
    authSubtitle.textContent = signingUp
        ? "Set up your account to access your patient workspace."
        : "Sign in to your patient insights workspace.";
    authSubmit.querySelector("span").textContent = signingUp
        ? "Create secure account"
        : "Sign in to workspace";
    setAuthMessage("");
}

function setAuthMessage(message, type = "") {
    authMessage.textContent = message;
    authMessage.classList.toggle("is-success", type === "success");
}

function setAuthLoading(loading) {
    authSubmit.disabled = loading;
    authSubmit.querySelector("span").textContent = loading
        ? (authMode === "signup" ? "Creating account…" : "Signing in…")
        : (authMode === "signup" ? "Create secure account" : "Sign in to workspace");
}

authForm.addEventListener("submit", async event => {
    event.preventDefault();
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    setAuthMessage("");

    if (authMode === "signup" && name.length < 2) {
        setAuthMessage("Enter your name using at least 2 characters.", "error");
        nameInput.focus();
        return;
    }
    if (!emailInput.validity.valid) {
        setAuthMessage("Enter a valid email address.", "error");
        emailInput.focus();
        return;
    }
    if (!password || (authMode === "signup" && password.length < 10)) {
        setAuthMessage(authMode === "signup"
            ? "Choose a password with at least 10 characters."
            : "Enter your password.", "error");
        passwordInput.focus();
        return;
    }

    setAuthLoading(true);
    try {
        const endpoint = authMode === "signup" ? "/api/auth/signup" : "/api/auth/login";
        const result = await api(endpoint, {
            method: "POST",
            body: JSON.stringify({ name, email, password })
        });
        await enterWorkspace(result.user);
    } catch (error) {
        setAuthMessage(error.message, "error");
    } finally {
        setAuthLoading(false);
    }
});

document.querySelector("#login-tab").addEventListener("click", () => setAuthMode("login"));
document.querySelector("#signup-tab").addEventListener("click", () => setAuthMode("signup"));
document.querySelector(".password-toggle").addEventListener("click", event => {
    const toggle = event.currentTarget;
    const visible = passwordInput.type === "text";
    passwordInput.type = visible ? "password" : "text";
    toggle.setAttribute("aria-label", visible ? "Show password" : "Hide password");
});

function enterWorkspace(user) {
    authScreen.classList.add("is-hidden");
    appScreen.classList.remove("is-hidden");
    document.querySelector("#profile-name").textContent = user.name;
    document.querySelector("#profile-email").textContent = user.email;
    document.querySelector("#profile-avatar").textContent = initials(user.name);
    document.querySelector("#welcome-heading").textContent = `A clearer picture, ${firstName(user.name)}.`;
    document.querySelector("#today-label").textContent = new Intl.DateTimeFormat(undefined, {
        weekday: "short", month: "short", day: "numeric", year: "numeric"
    }).format(new Date());
    setView("overview");
    return loadWorkspaceData();
}

function firstName(name) {
    return name.trim().split(/\s+/)[0] || "there";
}

function initials(name) {
    return name.trim().split(/\s+/).slice(0, 2).map(part => part[0].toUpperCase()).join("");
}

async function loadWorkspaceData() {
    setText("#stat-patients", "—");
    setText("#stat-urgent", "—");
    setText("#stat-departments", "—");
    document.querySelector("#recent-patients").replaceChildren(makeLoadingRow("Loading patient records…", 5));

    try {
        const [dashboard, patientData] = await Promise.all([
            api("/api/dashboard"),
            api("/api/patients")
        ]);
        patientRecords = patientData.patients;
        renderDashboard(dashboard);
        fillFilters(patientRecords);
        renderPatients(patientRecords.slice(0, 5), "#recent-patients");
        setText("#nav-count", patientRecords.length);
        if (activeView === "patients")
            await refreshSearch();
    } catch (error) {
        if (!authScreen.classList.contains("is-hidden"))
            return;
        showToast(error.message, true);
        setText("#stat-patients", "!");
        document.querySelector("#recent-patients")
            .replaceChildren(makeLoadingRow("Project records could not be loaded.", 5));
    }
}

function renderDashboard(dashboard) {
    setText("#stat-patients", dashboard.patientCount);
    setText("#stat-urgent", dashboard.urgentCount);
    setText("#stat-departments", dashboard.departmentCount);
    renderSeverity(dashboard);
    renderDiseases(dashboard.topDiseases);
}

function setText(selector, value) {
    document.querySelector(selector).textContent = String(value);
}

function renderSeverity(dashboard) {
    const chart = document.querySelector("#severity-chart");
    chart.replaceChildren();
    const labels = dashboard.severityOrder;
    const max = Math.max(1, ...labels.map(label => dashboard.severityCounts[label] || 0));
    for (const label of labels) {
        const count = dashboard.severityCounts[label] || 0;
        const column = document.createElement("div");
        column.className = "severity-column";
        const track = document.createElement("div");
        track.className = "severity-bar-track";
        const bar = document.createElement("progress");
        bar.className = "severity-bar";
        bar.max = 100;
        bar.value = count / max * 100;
        bar.setAttribute("aria-label", `${label}: ${count} records`);
        track.append(bar);
        const text = document.createElement("span");
        text.className = "severity-label";
        text.textContent = label;
        const total = document.createElement("span");
        total.className = "severity-count";
        total.textContent = count;
        column.append(track, text, total);
        chart.append(column);
    }
}

function renderDiseases(diseases) {
    const list = document.querySelector("#disease-list");
    list.replaceChildren();
    if (!diseases.length) {
        const message = document.createElement("p");
        message.className = "loading-state";
        message.textContent = "No condition data is available.";
        list.append(message);
        return;
    }
    const max = Math.max(...diseases.map(disease => disease.count));
    for (const disease of diseases) {
        const row = document.createElement("div");
        row.className = "disease-row";
        const name = document.createElement("span");
        name.className = "disease-name";
        name.textContent = disease.name;
        const track = document.createElement("progress");
        track.className = "disease-track";
        track.max = max;
        track.value = disease.count;
        const total = document.createElement("span");
        total.className = "disease-total";
        total.textContent = disease.count;
        row.append(name, track, total);
        list.append(row);
    }
}

function fillFilters(records) {
    const diseases = [...new Set(records.map(patient => patient.disease))]
        .sort((first, second) => first.localeCompare(second));
    const statuses = [...new Set(records.map(patient => patient.status))]
        .sort((first, second) => first.localeCompare(second));
    replaceOptions(diseaseFilter, "All conditions", diseases);
    replaceOptions(statusFilter, "All statuses", statuses);
}

function replaceOptions(select, firstLabel, options) {
    const selected = select.value;
    select.replaceChildren(new Option(firstLabel, ""));
    for (const option of options)
        select.add(new Option(option, option));
    if (options.includes(selected))
        select.value = selected;
}

function makeLoadingRow(message, columnCount) {
    const row = document.createElement("tr");
    const cell = document.createElement("td");
    cell.colSpan = columnCount;
    cell.className = "loading-state";
    cell.textContent = message;
    row.append(cell);
    return row;
}

function renderPatients(records, targetSelector) {
    const target = document.querySelector(targetSelector);
    target.replaceChildren();
    for (const patient of records) {
        const row = document.createElement("tr");
        const inDirectory = targetSelector === "#patient-results";
        row.className = "patient-row";
        row.append(
            makePatientCell(patient),
            !inDirectory
                ? makeTextCell(patient.disease)
                : makeConditionCell(patient),
            makeTextCell(patient.department),
            makeBadgeCell(patient.severity, "severity"),
            makeBadgeCell(patient.status, "status")
        );
        if (inDirectory) {
            const action = document.createElement("td");
            action.className = "detail-action-cell";
            const button = document.createElement("button");
            button.type = "button";
            button.className = "detail-trigger";
            button.dataset.patientId = patient.id;
            button.textContent = "View record";
            button.setAttribute("aria-label", `View complete record for ${patient.name}`);
            action.append(button);
            row.append(action);
        } else {
            const name = row.querySelector(".patient-name");
            const button = document.createElement("button");
            button.type = "button";
            button.className = "patient-name-button";
            button.dataset.patientId = patient.id;
            button.setAttribute("aria-label", `View complete record for ${patient.name}`);
            name.parentNode.replaceChild(button, name);
            button.append(name);
        }
        target.append(row);
    }
}

function makePatientCell(patient) {
    const cell = document.createElement("td");
    const wrapper = document.createElement("div");
    wrapper.className = "patient-cell";
    const avatar = document.createElement("span");
    avatar.className = "patient-avatar";
    avatar.textContent = initials(patient.name);
    const name = document.createElement("span");
    name.className = "patient-name";
    const strong = document.createElement("strong");
    strong.textContent = patient.name;
    const id = document.createElement("small");
    id.textContent = `${patient.id} · ${patient.age} years`;
    name.append(strong, id);
    wrapper.append(avatar, name);
    cell.append(wrapper);
    return cell;
}

function showPatientDetails(patientId) {
    const patient = patientRecords.find(record => record.id === patientId);
    if (!patient || !patient.details) {
        showToast("This patient’s full record could not be found.", true);
        return;
    }

    document.querySelector("#detail-name").textContent = patient.name;
    document.querySelector("#detail-subtitle").textContent =
        `${patient.id} · ${patient.age} years · ${patient.details.Gender || "Gender not recorded"}`;
    const grid = document.querySelector("#detail-grid");
    grid.replaceChildren();

    for (const [key, value] of Object.entries(patient.details)) {
        const field = document.createElement("div");
        field.className = key === "Emergency_Contact" || key === "Allergies"
            ? "detail-field detail-field-important"
            : "detail-field";
        const label = document.createElement("span");
        label.className = "detail-label";
        label.textContent = key.replace(/_/g, " ");
        const content = document.createElement("span");
        content.className = "detail-value";
        content.textContent = value;
        field.append(label, content);
        grid.append(field);
    }
    setText("#detail-field-count",
        `Showing all ${Object.keys(patient.details).length} fields from the project record`);

    const dialog = document.querySelector("#patient-dialog");
    if (!dialog.open)
        dialog.showModal();
}

document.querySelector("#patient-results").addEventListener("click", event => {
    const trigger = event.target.closest("[data-patient-id]");
    if (trigger)
        showPatientDetails(trigger.dataset.patientId);
});
document.querySelector("#recent-patients").addEventListener("click", event => {
    const trigger = event.target.closest("[data-patient-id]");
    if (trigger)
        showPatientDetails(trigger.dataset.patientId);
});
document.querySelector("#detail-close").addEventListener("click", () => {
    document.querySelector("#patient-dialog").close();
});
document.querySelector("#detail-done").addEventListener("click", () => {
    document.querySelector("#patient-dialog").close();
});
document.querySelector("#patient-dialog").addEventListener("click", event => {
    if (event.target === event.currentTarget)
        event.currentTarget.close();
});

function makeConditionCell(patient) {
    const cell = document.createElement("td");
    const wrapper = document.createElement("span");
    wrapper.className = "condition-cell";
    const disease = document.createElement("strong");
    disease.textContent = patient.disease;
    const symptoms = document.createElement("small");
    symptoms.textContent = patient.symptoms;
    wrapper.append(disease, symptoms);
    cell.append(wrapper);
    return cell;
}

function makeTextCell(value) {
    const cell = document.createElement("td");
    cell.textContent = value;
    return cell;
}

function makeBadgeCell(value, type) {
    const cell = document.createElement("td");
    const badge = document.createElement("span");
    const normalized = value.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    badge.className = type === "severity"
        ? `severity-badge severity-${normalized}`
        : "status-badge";
    badge.textContent = value;
    cell.append(badge);
    return cell;
}

function setView(view) {
    if (!["overview", "patients", "algorithms"].includes(view))
        return;
    activeView = view;
    for (const section of document.querySelectorAll(".view"))
        section.classList.toggle("is-active", section.id === `view-${view}`);
    for (const item of document.querySelectorAll(".nav-item"))
        item.classList.toggle("is-active", item.dataset.view === view);
    const labels = { overview: "Overview", patients: "Patient records", algorithms: "Search algorithms" };
    document.querySelector("#breadcrumb-current").textContent = labels[view];
    document.querySelector("#sidebar").classList.remove("is-open");
    document.querySelector("#mobile-scrim").classList.remove("is-visible");
    if (view === "patients") {
        if (patientRecords.length > 0)
            scheduleSearch();
        window.setTimeout(() => patientSearch.focus({ preventScroll: true }), 60);
    }
}

document.querySelectorAll("[data-view]").forEach(button => {
    button.addEventListener("click", () => setView(button.dataset.view));
});
document.querySelectorAll("[data-view-link]").forEach(button => {
    button.addEventListener("click", event => {
        event.preventDefault();
        setView(button.dataset.viewLink);
    });
});

function scheduleSearch() {
    window.clearTimeout(searchTimer);
    searchTimer = window.setTimeout(refreshSearch, 180);
}

async function refreshSearch() {
    if (activeView !== "patients")
        return;
    const requestId = ++searchRequestId;
    const results = document.querySelector("#patient-results");
    const empty = document.querySelector("#empty-results");
    const table = document.querySelector(".directory-table-wrap");
    empty.classList.add("is-hidden");
    table.classList.remove("is-hidden");
    results.replaceChildren(makeLoadingRow("Searching project records…", 6));

    const parameters = new URLSearchParams({
        q: patientSearch.value.trim(),
        method: searchMethod.value,
        disease: diseaseFilter.value,
        status: statusFilter.value
    });
    try {
        const result = await api(`/api/patients?${parameters}`);
        if (requestId !== searchRequestId)
            return;
        setText("#results-count",
            `${result.patients.length} ${result.patients.length === 1 ? "record" : "records"}`);
        renderPatients(result.patients, "#patient-results");
        const noResults = result.patients.length === 0;
        table.classList.toggle("is-hidden", noResults);
        empty.classList.toggle("is-hidden", !noResults);
    } catch (error) {
        if (requestId !== searchRequestId)
            return;
        results.replaceChildren(makeLoadingRow(error.message, 6));
        setText("#results-count", "Search unavailable");
    }
}

patientSearch.addEventListener("input", scheduleSearch);
searchMethod.addEventListener("change", scheduleSearch);
diseaseFilter.addEventListener("change", scheduleSearch);
statusFilter.addEventListener("change", scheduleSearch);
document.querySelector("#clear-search").addEventListener("click", () => {
    patientSearch.value = "";
    diseaseFilter.value = "";
    statusFilter.value = "";
    scheduleSearch();
});
document.querySelectorAll("[data-try-method]").forEach(button => {
    button.addEventListener("click", () => {
        searchMethod.value = button.dataset.tryMethod;
        setView("patients");
        showToast(`${searchMethod.options[searchMethod.selectedIndex].text} is ready.`);
    });
});

document.querySelector("#mobile-menu").addEventListener("click", () => {
    document.querySelector("#sidebar").classList.add("is-open");
    document.querySelector("#mobile-scrim").classList.add("is-visible");
});
document.querySelector("#mobile-scrim").addEventListener("click", () => {
    document.querySelector("#sidebar").classList.remove("is-open");
    document.querySelector("#mobile-scrim").classList.remove("is-visible");
});
document.querySelector("#logout-button").addEventListener("click", signOut);
document.querySelector("#profile-button").addEventListener("click", signOut);

async function signOut() {
    try {
        await api("/api/auth/logout", { method: "POST" });
    } catch (error) {
        showToast(error.message, true);
    }
    patientRecords = [];
    const patientDialog = document.querySelector("#patient-dialog");
    if (patientDialog.open)
        patientDialog.close();
    authForm.reset();
    showAuth();
}

function showToast(message, isError = false) {
    const toast = document.querySelector("#toast");
    toast.textContent = message;
    toast.classList.toggle("is-error", isError);
    toast.classList.add("is-visible");
    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => toast.classList.remove("is-visible"), 3200);
}

document.addEventListener("keydown", event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        if (authScreen.classList.contains("is-hidden")) {
            setView("patients");
            patientSearch.focus();
        } else {
            emailInput.focus();
        }
    }
    if (event.key === "Escape") {
        document.querySelector("#sidebar").classList.remove("is-open");
        document.querySelector("#mobile-scrim").classList.remove("is-visible");
    }
});

async function initialize() {
    try {
        const result = await api("/api/session");
        if (result.user)
            await enterWorkspace(result.user);
        else
            showAuth();
    } catch (error) {
        showAuth();
        setAuthMessage(error.message, "error");
    }
}

initialize();
