# DSA---3-MediSearch-Project

## Run

From the project root:

```text
javac -d . src\*.java src\algorithms\*.java
java Main
```

The search reads all patient records from `src/corpus_txt`. Available algorithms:

- KMP
- Z Algorithm
- Trie
- Edit Distance
- Aho-Corasick
- Smith-Waterman
- Optimal BST disease lookup