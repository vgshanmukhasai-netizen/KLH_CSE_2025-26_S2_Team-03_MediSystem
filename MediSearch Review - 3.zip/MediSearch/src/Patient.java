public class Patient {

    private String patientId;
    private String name;
    private int age;
    private String disease;
    private String symptoms;
    private String severity;
    private String searchableText;

    public Patient(String patientId, String name,
                   int age, String disease,
                   String symptoms, String severity) {

            this(patientId, name, age, disease, symptoms, severity,
                 patientId + "\n" + name + "\n" + age + "\n" + disease + "\n" +
                 symptoms + "\n" + severity);
            }

            public Patient(String patientId, String name,
                   int age, String disease,
                   String symptoms, String severity,
                   String searchableText) {

        this.patientId = patientId;
        this.name = name;
        this.age = age;
        this.disease = disease;
        this.symptoms = symptoms;
        this.severity = severity;
        this.searchableText = searchableText;
    }

    public String getPatientId() {
        return patientId;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getDisease() {
        return disease;
    }

    public String getSymptoms() {
        return symptoms;
    }

    public String getSeverity() {
        return severity;
    }

    public String getSearchableText() {
        return searchableText;
    }

    @Override
    public String toString() {
        return patientId + " | " +
               name + " | " +
               age + " | " +
               disease + " | " +
               symptoms + " | " +
               severity;
    }
}