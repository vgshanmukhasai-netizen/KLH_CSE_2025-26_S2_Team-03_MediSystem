import java.io.*;
import java.util.*;

public class CorpusLoader {

    public static List<Patient> loadCorpus() {

        List<Patient> patients = new ArrayList<>();

        try {

            File folder = new File("corpus_txt");

            if (!folder.isDirectory())
                folder = new File("src", "corpus_txt");

            File[] files = folder.listFiles();

            if(files == null)
                return patients;

            for(File file : files) {

                if (!file.isFile() || !file.getName().toLowerCase().endsWith(".txt"))
                    continue;

                StringBuilder fileContents = new StringBuilder();

                String id = "";
                String name = "";
                int age = 0;
                String disease = "";
                String symptoms = "";
                String severity = "";

                try (Scanner sc = new Scanner(file, "UTF-8")) {
                    while(sc.hasNextLine()) {

                        String line = sc.nextLine();
                        fileContents.append(line).append('\n');

                        if(line.startsWith("Patient_ID:"))
                            id = line.split(":", 2)[1].trim();

                        else if(line.startsWith("Name:"))
                            name = line.split(":", 2)[1].trim();

                        else if(line.startsWith("Age:"))
                            age = Integer.parseInt(line.split(":", 2)[1].trim());

                        else if(line.startsWith("Disease:"))
                            disease = line.split(":", 2)[1].trim();

                        else if(line.startsWith("Symptoms:"))
                            symptoms = line.split(":", 2)[1].trim();

                        else if(line.startsWith("Severity:"))
                            severity = line.split(":", 2)[1].trim();
                    }

                    patients.add(
                            new Patient(
                                    id,
                                    name,
                                    age,
                                    disease,
                                    symptoms,
                                    severity,
                                    fileContents.toString()
                            )
                    );
                }
            }

        } catch (IOException | NumberFormatException | SecurityException e) {
            System.err.println("Unable to load corpus: " + e.getMessage());
        }

        return patients;
    }
}