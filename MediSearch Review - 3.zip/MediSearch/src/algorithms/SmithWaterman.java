package algorithms;

public class SmithWaterman {

    private static final int MATCH = 2;
    private static final int MISMATCH = -1;
    private static final int GAP = -1;

    public static int score(String text, String pattern) {

        int[] previous = new int[pattern.length() + 1];
        int best = 0;

        for (int i = 1; i <= text.length(); i++) {
            int[] current = new int[pattern.length() + 1];

            for (int j = 1; j <= pattern.length(); j++) {
                int diagonal = previous[j - 1]
                        + (text.charAt(i - 1) == pattern.charAt(j - 1)
                        ? MATCH : MISMATCH);
                int deletion = previous[j] + GAP;
                int insertion = current[j - 1] + GAP;

                current[j] = Math.max(0,
                        Math.max(diagonal, Math.max(deletion, insertion)));
                best = Math.max(best, current[j]);
            }

            previous = current;
        }

        return best;
    }
}