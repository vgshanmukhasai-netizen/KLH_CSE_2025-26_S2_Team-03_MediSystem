package algorithms;

public class OptimalBST {

    private static class Node {
        private final String key;
        private Node left;
        private Node right;

        private Node(String key) {
            this.key = key;
        }
    }

    private final Node root;

    private OptimalBST(Node root) {
        this.root = root;
    }

    public static OptimalBST build(String[] keys, double[] probabilities) {

        if (keys.length == 0 || keys.length != probabilities.length)
            throw new IllegalArgumentException("Keys and probabilities must have the same non-zero length");

        String[] sortedKeys = keys.clone();
        double[] sortedProbabilities = probabilities.clone();

        for (int i = 0; i < sortedKeys.length - 1; i++) {
            for (int j = i + 1; j < sortedKeys.length; j++) {
                if (sortedKeys[i].compareTo(sortedKeys[j]) > 0) {
                    String key = sortedKeys[i];
                    sortedKeys[i] = sortedKeys[j];
                    sortedKeys[j] = key;

                    double probability = sortedProbabilities[i];
                    sortedProbabilities[i] = sortedProbabilities[j];
                    sortedProbabilities[j] = probability;
                }
            }
        }

        int size = sortedKeys.length;
        double[][] cost = new double[size][size];
        int[][] roots = new int[size][size];

        for (int i = 0; i < size; i++) {
            cost[i][i] = sortedProbabilities[i];
            roots[i][i] = i;
        }

        for (int length = 2; length <= size; length++) {
            for (int start = 0; start <= size - length; start++) {
                int end = start + length - 1;
                double weight = 0;

                for (int i = start; i <= end; i++)
                    weight += sortedProbabilities[i];

                cost[start][end] = Double.POSITIVE_INFINITY;

                for (int root = start; root <= end; root++) {
                    double left = root > start ? cost[start][root - 1] : 0;
                    double right = root < end ? cost[root + 1][end] : 0;
                    double candidate = left + right + weight;

                    if (candidate < cost[start][end]) {
                        cost[start][end] = candidate;
                        roots[start][end] = root;
                    }
                }
            }
        }

        return new OptimalBST(buildTree(sortedKeys, roots, 0, size - 1));
    }

    private static Node buildTree(String[] keys, int[][] roots, int start, int end) {
        if (start > end)
            return null;

        int rootIndex = roots[start][end];
        Node node = new Node(keys[rootIndex]);
        node.left = buildTree(keys, roots, start, rootIndex - 1);
        node.right = buildTree(keys, roots, rootIndex + 1, end);
        return node;
    }

    public boolean search(String key) {

        Node current = root;

        while (current != null) {
            int comparison = key.compareTo(current.key);

            if (comparison == 0)
                return true;

            current = comparison < 0 ? current.left : current.right;
        }

        return false;
    }
}