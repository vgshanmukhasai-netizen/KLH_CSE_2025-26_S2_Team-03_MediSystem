import algorithms.*;
import java.util.*;

public class SearchEngine {

    private final List<Patient> patients;

    public SearchEngine() {
        patients = CorpusLoader.loadCorpus();
    }

    public void searchKMP(String query) {

        System.out.println("\nKMP Results:");
        query = query.trim().toLowerCase(Locale.ROOT);

        for (Patient p : patients) {

            if (KMP.search(
                    p.getSearchableText().toLowerCase(Locale.ROOT),
                    query)) {

                System.out.println(p);
            }
        }
    }

    public void searchZ(String query) {

        System.out.println("\nZ Results:");
        query = query.trim().toLowerCase(Locale.ROOT);

        for (Patient p : patients) {

            if (ZAlgorithm.search(
                    p.getSearchableText().toLowerCase(Locale.ROOT),
                    query)) {

                System.out.println(p);
            }
        }
    }

    public void searchTrie(String disease) {

        Trie trie = new Trie();
        disease = disease.trim().toLowerCase(Locale.ROOT);

        for (Patient p : patients) {
            trie.insert(
                    p.getDisease().toLowerCase(Locale.ROOT)
            );
        }

        System.out.println(
                "\nTrie Search Result = "
                + trie.search(disease)
        );
    }

    public void searchEditDistance(String query) {

        System.out.println(
                "\nClosest Matches:"
        );

        query = query.trim().toLowerCase(Locale.ROOT);

        for (Patient p : patients) {

            int dist =
                    EditDistance.calculate(
                            query,
                            p.getDisease().toLowerCase(Locale.ROOT)
                    );

            if (dist <= 2) {

                System.out.println(
                        p + " | Distance="
                        + dist
                );
            }
        }
    }

    public void searchAho(String query) {

        query = query.trim().toLowerCase(Locale.ROOT);

        AhoCorasick aho =
                new AhoCorasick();

        aho.addPattern(query);

        aho.buildFailureLinks();

        System.out.println(
                "\nAho-Corasick Results:"
        );

        for (Patient p : patients) {

            List<String> matches =
                    aho.search(
                            p.getSearchableText().toLowerCase(Locale.ROOT)
                    );

            if (!matches.isEmpty()) {

                System.out.println(p);
            }
        }
    }

    public void searchSmithWaterman(String query) {

        query = query.trim().toLowerCase(Locale.ROOT);
        int threshold = Math.max(2, query.length());

        System.out.println("\nSmith-Waterman Results:");

        for (Patient p : patients) {
            int score = SmithWaterman.score(
                    p.getSearchableText().toLowerCase(Locale.ROOT),
                    query
            );

            if (score >= threshold)
                System.out.println(p + " | Score=" + score);
        }
    }

    public void searchOptimalBST(String disease) {

        disease = disease.trim().toLowerCase(Locale.ROOT);
        Map<String, Integer> frequencies = new TreeMap<>();

        for (Patient p : patients) {
            String key = p.getDisease().toLowerCase(Locale.ROOT);
            frequencies.put(key, frequencies.getOrDefault(key, 0) + 1);
        }

        String[] diseases = frequencies.keySet().toArray(new String[0]);
        double[] probabilities = new double[diseases.length];

        for (int i = 0; i < diseases.length; i++)
            probabilities[i] = frequencies.get(diseases[i]);

        OptimalBST tree = OptimalBST.build(diseases, probabilities);
        boolean diseaseFound = tree.search(disease);

        System.out.println("\nOptimal BST Results:");
        System.out.println("Disease Found = " + diseaseFound);

        if (!diseaseFound) {
            System.out.println("No patients found for disease: " + disease);
            return;
        }

        System.out.println("Patients with disease: " + disease);

        for (Patient p : patients) {
            if (p.getDisease().trim().equalsIgnoreCase(disease))
                System.out.println(p);
        }
    }
}